#ifndef _ZIP_H__
#define _ZIP_H__

//---------------------------------------------------------------------------
// ZIP�t�@�C�����𓀂���
bool Unzip(const string &strZipFilename, const string &strTargetPath);

#endif //_ZIP_H__
